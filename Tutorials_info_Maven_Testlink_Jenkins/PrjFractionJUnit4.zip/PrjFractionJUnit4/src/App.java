

public class App {

	public static void main(String[] args) {
		
		Fraction f1 = new Fraction(2,3);
		System.out.println(f1);
		

		Fraction f2 = new Fraction(2,6);
		System.out.println(f2);

		Fraction f3 = new Fraction(0,2);
		System.out.println(f3);

		Fraction f4 = new Fraction(2,0);
		System.out.println(f4);
		
	}
}
