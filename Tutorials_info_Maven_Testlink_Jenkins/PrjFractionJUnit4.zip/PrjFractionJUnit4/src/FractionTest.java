import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;


public class FractionTest {

	private Fraction fc1, fc2;
	
	
	@BeforeClass
	public static void setUpAll() {
		System.out.println("Setup for all subsequent tests...");
		//setup
	}
	
	@Before
	public void setup() {
		System.out.println("\nsingle test setup:");

		fc1 = new Fraction(12,30);
		fc2 = new Fraction(-25,7);

		System.out.println(fc1);
		System.out.println(fc2);
	}

	@Test
	public void mySimplifyTest() {
		System.out.println("\ntestSimplify");
		fc1.Simplify();
		assertEquals(2, fc1.getNumerator());
		assertEquals(5, fc1.getDenominator());
		
		fc2.Simplify();
		assertEquals(-25, fc2.getNumerator());
		assertEquals(7, fc2.getDenominator());
	}

	//@Ignore
	@Test
	public void testGetDenominator() {
		System.out.println("\ntestGetDenominator");
		int result = fc1.getDenominator();
		assertTrue("getDenominator() returned " + result + " instead of 30.", result == 5);
		result = fc2.getDenominator();
		assertEquals(7, result);
				
	}
	
	//@Ignore
	@Test
	public void testSetDenominator() {
		
		System.out.println("\ntestSetDenominator");
		try {
			fc1.setDenominator(1);
		} catch (Exception e) {
			e.printStackTrace();
		}
		int result = fc1.getDenominator();
		assertTrue("getDenominator() returned " + result + " instead of 1.", result == 1);
		fc2.setNumerator(6);
		result = fc2.getNumerator();
		assertEquals(6, result);
	}
	
	@Test (timeout=10)
	public void testDivision() {
		
		System.out.println("\ntestDivision");
		try {
			fc1.div(fc2);
		} catch (Exception e) {
			e.printStackTrace();
		}		
		assertEquals(-14, fc1.getNumerator());
		assertEquals(125, fc1.getDenominator());
	}
	
	@Test (expected=Exception.class)
	public void testDivisionException() throws Exception{
		
		System.out.println("\ntestDivisionException");
		fc2.setDenominator(0);
		fc1.div(fc2);		
		//assertEquals(0, fc1.getDenominator());
	}
	
	
	
	@After
	public void teardown() {
		
		System.out.println("\nsingle test tearing down");
		fc1 = fc2 = null;
		System.out.println(fc1);
		System.out.println(fc2);
	}
	
	@AfterClass
	public static void tearDownAll() {
		System.out.println("\ntearing all down");
	}
}
